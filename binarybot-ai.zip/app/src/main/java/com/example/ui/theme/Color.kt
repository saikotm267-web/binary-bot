package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Professional Polish Theme Palette
val ProBg = Color(0xFF0F1115)
val ProCard = Color(0xFF1F242D)
val ProItem = Color(0xFF2A313C)
val ProAccentBlue = Color(0xFFD0E4FF)
val ProAccentBlueDark = Color(0xFF00315E)
val ProAccentBlueMuted = Color(0xFF3E4759)
val ProBorder = Color(0xFF2D3440)
val ProBorderLight = Color(0xFF4F5B73)

val TextPrimary = Color(0xFFE2E2E6)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val BuyGreen = Color(0xFF10B981)
val BuyGreenLight = Color(0xFF34D399)
val SellRed = Color(0xFFF43F5E)
val WaitAmber = Color(0xFFF59E0B)

// Backward compatible aliases
val DarkBg = ProBg
val DarkSurface = ProCard
val DarkCard = ProCard
val DarkCardBorder = ProBorder
val DarkCardHighlight = ProItem
val CyberCyan = ProAccentBlue
val NeonGreen = BuyGreen
val NeonRed = SellRed
val NeonGold = WaitAmber
