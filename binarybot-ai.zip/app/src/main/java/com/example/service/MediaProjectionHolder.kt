package com.example.service

import android.content.Intent
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager

object MediaProjectionHolder {
    var resultCode: Int = 0
    var resultData: Intent? = null
    var mediaProjection: MediaProjection? = null

    fun hasPermission(): Boolean {
        return resultCode != 0 && resultData != null
    }

    fun initProjection(manager: MediaProjectionManager): MediaProjection? {
        if (mediaProjection != null) return mediaProjection
        val data = resultData ?: return null
        return try {
            val proj = manager.getMediaProjection(resultCode, data)
            mediaProjection = proj
            proj
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun clear() {
        try {
            mediaProjection?.stop()
        } catch (e: Exception) {
            // ignore
        }
        mediaProjection = null
        resultCode = 0
        resultData = null
    }
}
