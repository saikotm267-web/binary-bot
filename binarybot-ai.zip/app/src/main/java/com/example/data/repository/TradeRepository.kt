package com.example.data.repository

import com.example.data.db.TradeDao
import com.example.data.db.TradeEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

data class TradeStats(
    val totalTrades: Int = 0,
    val totalWins: Int = 0,
    val totalLosses: Int = 0,
    val totalTies: Int = 0,
    val winRate: Float = 0f,
    val currentStreak: Int = 0
)

class TradeRepository(private val tradeDao: TradeDao) {
    val allTrades: Flow<List<TradeEntity>> = tradeDao.getAllTrades()

    val stats: Flow<TradeStats> = combine(
        tradeDao.getAllTrades(),
        tradeDao.getWinCount(),
        tradeDao.getLossCount(),
        tradeDao.getTieCount()
    ) { trades, wins, losses, ties ->
        val resolved = wins + losses
        val winRate = if (resolved > 0) (wins.toFloat() / resolved.toFloat()) * 100f else 0f

        // Calculate current streak
        var streak = 0
        val resolvedTrades = trades.filter { it.result == "WIN" || it.result == "LOSS" }
        if (resolvedTrades.isNotEmpty()) {
            val firstResult = resolvedTrades.first().result
            for (t in resolvedTrades) {
                if (t.result == firstResult) {
                    if (firstResult == "WIN") streak++ else streak--
                } else {
                    break
                }
            }
        }

        TradeStats(
            totalTrades = trades.size,
            totalWins = wins,
            totalLosses = losses,
            totalTies = ties,
            winRate = winRate,
            currentStreak = streak
        )
    }

    suspend fun insertTrade(trade: TradeEntity): Long = tradeDao.insertTrade(trade)

    suspend fun updateResult(id: Long, result: String) = tradeDao.updateTradeResult(id, result)

    suspend fun deleteTrade(id: Long) = tradeDao.deleteTradeById(id)

    suspend fun clearHistory() = tradeDao.clearAllTrades()
}
