package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TradeDao {
    @Query("SELECT * FROM trades ORDER BY timestamp DESC")
    fun getAllTrades(): Flow<List<TradeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrade(trade: TradeEntity): Long

    @Update
    suspend fun updateTrade(trade: TradeEntity)

    @Query("UPDATE trades SET result = :result WHERE id = :id")
    suspend fun updateTradeResult(id: Long, result: String)

    @Query("DELETE FROM trades WHERE id = :id")
    suspend fun deleteTradeById(id: Long)

    @Query("DELETE FROM trades")
    suspend fun clearAllTrades()

    @Query("SELECT COUNT(*) FROM trades WHERE result = 'WIN'")
    fun getWinCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM trades WHERE result = 'LOSS'")
    fun getLossCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM trades WHERE result = 'TIE'")
    fun getTieCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM trades WHERE result != 'PENDING'")
    fun getTotalResolvedCount(): Flow<Int>
}
