package com.example

import android.app.Application
import com.example.data.db.TradeDatabase
import com.example.data.preferences.SettingsRepository
import com.example.data.repository.TradeRepository

class BinaryBotApplication : Application() {

    lateinit var database: TradeDatabase
        private set

    lateinit var tradeRepository: TradeRepository
        private set

    lateinit var settingsRepository: SettingsRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = TradeDatabase.getDatabase(this)
        tradeRepository = TradeRepository(database.tradeDao())
        settingsRepository = SettingsRepository(this)
    }
}
