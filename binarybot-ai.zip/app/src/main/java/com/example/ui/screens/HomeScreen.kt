package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.SignalResult
import com.example.data.model.SignalType
import com.example.service.FloatingBotService
import com.example.service.MediaProjectionHolder
import com.example.ui.ApiTestState
import com.example.ui.MainViewModel
import com.example.ui.theme.BuyGreen
import com.example.ui.theme.BuyGreenLight
import com.example.ui.theme.ProAccentBlue
import com.example.ui.theme.ProAccentBlueDark
import com.example.ui.theme.ProAccentBlueMuted
import com.example.ui.theme.ProBg
import com.example.ui.theme.ProBorder
import com.example.ui.theme.ProBorderLight
import com.example.ui.theme.ProCard
import com.example.ui.theme.ProItem
import com.example.ui.theme.SellRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WaitAmber

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onOpenPermissions: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val clipboardManager = LocalClipboardManager.current

    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val isBotRunning by viewModel.isBotRunning.collectAsStateWithLifecycle()
    val lastFloatingSignal by viewModel.lastFloatingSignal.collectAsStateWithLifecycle()
    val inAppAnalysisResult by viewModel.inAppAnalysisResult.collectAsStateWithLifecycle()
    val isInAppAnalyzing by viewModel.isInAppAnalyzing.collectAsStateWithLifecycle()
    val inAppError by viewModel.inAppError.collectAsStateWithLifecycle()
    val apiTestState by viewModel.apiTestState.collectAsStateWithLifecycle()

    var apiKeyInput by remember(settings.apiKey) { mutableStateOf(settings.apiKey) }
    var isApiKeyVisible by remember { mutableStateOf(false) }

    var selectedPattern by remember { mutableStateOf("bullish_hammer") }
    var currentSampleBitmap by remember { mutableStateOf<Bitmap?>(viewModel.createSampleChartBitmap("bullish_hammer")) }

    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            try {
                val bitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    val source = ImageDecoder.createSource(context.contentResolver, it)
                    ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                        decoder.isMutableRequired = true
                    }
                } else {
                    @Suppress("DEPRECATION")
                    MediaStore.Images.Media.getBitmap(context.contentResolver, it)
                }
                currentSampleBitmap = bitmap
                viewModel.analyzeChartBitmap(bitmap, chartName = "Gallery Screenshot")
            } catch (e: Exception) {
                Toast.makeText(context, "Could not load image: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ProBg)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Hero Card (Professional Polish Header)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp),
            shape = RoundedCornerShape(28.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, ProBorder)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Image(
                    painter = painterResource(id = R.drawable.hero_trading_ai),
                    contentDescription = "BinaryEdge AI Pro",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    ProBg.copy(alpha = 0.95f),
                                    ProBg.copy(alpha = 0.75f),
                                    Color.Transparent
                                )
                            )
                        )
                )

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(BuyGreen)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "PRICE ACTION & S/R SPECIALIST",
                            color = BuyGreenLight,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "BinaryEdge Pro",
                        color = ProAccentBlue,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Text(
                        text = ">95% Target Accuracy Decision Engine",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Big Primary Toggle Button (START / STOP FLOATING BOT)
        Button(
            onClick = {
                if (isBotRunning) {
                    val stopIntent = Intent(context, FloatingBotService::class.java).apply {
                        action = FloatingBotService.ACTION_STOP
                    }
                    context.startService(stopIntent)
                } else {
                    val canOverlay = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        Settings.canDrawOverlays(context)
                    } else true
                    val hasProjection = MediaProjectionHolder.hasPermission()

                    if (!canOverlay || !hasProjection) {
                        onOpenPermissions()
                        Toast.makeText(context, "Please complete System Readiness setup first!", Toast.LENGTH_SHORT).show()
                    } else {
                        val startIntent = Intent(context, FloatingBotService::class.java).apply {
                            action = FloatingBotService.ACTION_START
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            context.startForegroundService(startIntent)
                        } else {
                            context.startService(startIntent)
                        }
                        Toast.makeText(context, "🤖 Floating Bot active over your broker!", Toast.LENGTH_SHORT).show()
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(58.dp)
                .testTag("toggle_floating_bot_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isBotRunning) SellRed else ProAccentBlue,
                contentColor = if (isBotRunning) Color.White else ProAccentBlueDark
            ),
            shape = RoundedCornerShape(24.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = if (isBotRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isBotRunning) "STOP FLOATING BOT" else "START FLOATING BOT",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    letterSpacing = 0.5.sp
                )
            }
        }

        // Live Pop-up Signal Display (if recently analyzed)
        lastFloatingSignal?.let { signal ->
            Spacer(modifier = Modifier.height(16.dp))
            ProfessionalSignalCard(
                signal = signal,
                title = "LIVE ANALYSIS",
                onMarkOutcome = { outcome ->
                    Toast.makeText(context, "Trade logged as $outcome!", Toast.LENGTH_SHORT).show()
                }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // API Key Section (Professional Polish Card)
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ProCard),
            shape = RoundedCornerShape(28.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, ProBorder)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "GEMINI API KEY CONFIGURATION",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = apiKeyInput,
                    onValueChange = { apiKeyInput = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("gemini_api_key_input"),
                    placeholder = { Text("AIzaSy...", color = TextMuted, fontFamily = FontFamily.Monospace) },
                    singleLine = true,
                    visualTransformation = if (isApiKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Done
                    ),
                    trailingIcon = {
                        Row {
                            IconButton(onClick = {
                                val clip = clipboardManager.getText()?.text ?: ""
                                if (clip.isNotBlank()) apiKeyInput = clip.trim()
                            }) {
                                Icon(imageVector = Icons.Default.ContentPaste, contentDescription = "Paste", tint = ProAccentBlue)
                            }
                            IconButton(onClick = { isApiKeyVisible = !isApiKeyVisible }) {
                                Icon(
                                    imageVector = if (isApiKeyVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle Visibility",
                                    tint = TextSecondary
                                )
                            }
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = ProBg,
                        unfocusedContainerColor = ProBg,
                        focusedBorderColor = ProAccentBlue,
                        unfocusedBorderColor = ProBorderLight,
                        focusedTextColor = ProAccentBlue,
                        unfocusedTextColor = ProAccentBlue
                    ),
                    shape = RoundedCornerShape(14.dp)
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            viewModel.saveApiKey(apiKeyInput)
                            focusManager.clearFocus()
                            Toast.makeText(context, "API Key saved securely!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("save_api_key_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = ProAccentBlueMuted, contentColor = ProAccentBlue),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("SAVE KEY", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            viewModel.saveApiKey(apiKeyInput)
                            viewModel.testApiConnection()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("test_api_connection_button"),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = BuyGreenLight),
                        border = androidx.compose.foundation.BorderStroke(1.dp, ProBorderLight),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (apiTestState is ApiTestState.Testing) {
                            CircularProgressIndicator(
                                color = BuyGreen,
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text("TEST API", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }

                AnimatedVisibility(visible = apiTestState !is ApiTestState.Idle) {
                    Column(modifier = Modifier.padding(top = 10.dp)) {
                        when (val state = apiTestState) {
                            is ApiTestState.Success -> {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = BuyGreen.copy(alpha = 0.12f),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, BuyGreen.copy(alpha = 0.4f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = BuyGreen, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(text = state.message, color = BuyGreen, fontSize = 12.sp)
                                    }
                                }
                            }
                            is ApiTestState.Error -> {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = SellRed.copy(alpha = 0.12f),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, SellRed.copy(alpha = 0.4f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(imageVector = Icons.Default.Error, contentDescription = null, tint = SellRed, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(text = state.message, color = SellRed, fontSize = 12.sp)
                                    }
                                }
                            }
                            else -> {}
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Strategy & Expiry Timeframe Section
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ProCard),
            shape = RoundedCornerShape(28.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, ProBorder)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "STRATEGY & EXPIRY TIMEFRAME",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("1 MIN", "2 MIN", "5 MIN", "15 MIN").forEach { tf ->
                        val isSelected = settings.timeframe == tf
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.saveTimeframe(tf) },
                            label = { Text(tf, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ProAccentBlue,
                                selectedLabelColor = ProAccentBlueDark,
                                containerColor = ProItem,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = ProBorder,
                                selectedBorderColor = ProAccentBlue
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = ProBorder, thickness = 1.dp)
                Spacer(modifier = Modifier.height(14.dp))

                // Haptic feedback switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Haptic Vibration Alert", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Switch(
                        checked = settings.hapticFeedback,
                        onCheckedChange = { viewModel.saveHaptic(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = BuyGreen,
                            uncheckedThumbColor = TextMuted,
                            uncheckedTrackColor = ProItem
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // In-App Interactive Chart Sandbox
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ProCard),
            shape = RoundedCornerShape(28.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, ProBorder)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "IN-APP CHART TESTER",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )

                    OutlinedButton(
                        onClick = { galleryLauncher.launch("image/*") },
                        modifier = Modifier.height(32.dp),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, ProBorderLight)
                    ) {
                        Text("Gallery", fontSize = 10.sp, color = ProAccentBlue)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        Pair("bullish_hammer", "Support Pin"),
                        Pair("bearish_rejection", "Resistance"),
                        Pair("choppy", "Choppy")
                    ).forEach { (pattern, label) ->
                        val isSelected = selectedPattern == pattern
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                selectedPattern = pattern
                                currentSampleBitmap = viewModel.createSampleChartBitmap(pattern)
                                viewModel.clearInAppResult()
                            },
                            label = { Text(label, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ProAccentBlueMuted,
                                selectedLabelColor = ProAccentBlue,
                                containerColor = ProItem,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = ProBorder,
                                selectedBorderColor = ProAccentBlue
                            ),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                currentSampleBitmap?.let { bmp ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.dp, ProBorder, RoundedCornerShape(16.dp))
                            .background(Color(0xFF0A0C10)),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = "Chart",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )

                        if (isInAppAnalyzing) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color.Black.copy(alpha = 0.75f)),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(color = ProAccentBlue, modifier = Modifier.size(32.dp))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = {
                        currentSampleBitmap?.let {
                            viewModel.analyzeChartBitmap(it, "Sandbox: $selectedPattern")
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("analyze_chart_sandbox_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = ProAccentBlue, contentColor = ProAccentBlueDark),
                    shape = RoundedCornerShape(16.dp),
                    enabled = !isInAppAnalyzing
                ) {
                    Text("ANALYZE TEST CHART", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                inAppAnalysisResult?.let { res ->
                    Spacer(modifier = Modifier.height(16.dp))
                    ProfessionalSignalCard(
                        signal = res,
                        title = "AI ANALYSIS OUTPUT",
                        onMarkOutcome = null
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun ProfessionalSignalCard(
    signal: SignalResult,
    title: String,
    onMarkOutcome: ((String) -> Unit)? = null
) {
    val isBuy = signal.normalizedSignal == SignalType.BUY
    val isSell = signal.normalizedSignal == SignalType.SELL

    val signalColor = when {
        isBuy -> BuyGreen
        isSell -> SellRed
        else -> WaitAmber
    }

    val signalLabel = when {
        isBuy -> "CALL (BUY)"
        isSell -> "PUT (SELL)"
        else -> "WAIT"
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = Color(0xFF0A0C10),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, signalColor.copy(alpha = 0.6f))
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(signalColor)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = title,
                        color = signalColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = ProCard
                ) {
                    Text(
                        text = signal.timeframe,
                        color = TextPrimary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Signal:",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
                Text(
                    text = signalLabel,
                    color = signalColor,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Confidence:",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = ProCard
                ) {
                    Text(
                        text = signal.confidence,
                        color = ProAccentBlue,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = Color.White.copy(alpha = 0.06f), thickness = 1.dp)
            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = """{ "signal": "${signal.signal}", "confidence": "${signal.confidence}", "timeframe": "${signal.timeframe}" }""",
                color = TextMuted,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp
            )

            if (onMarkOutcome != null) {
                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onMarkOutcome("WIN") },
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BuyGreen),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("WIN 🎯", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { onMarkOutcome("LOSS") },
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SellRed),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("LOSS ❌", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { onMarkOutcome("TIE") },
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ProAccentBlueMuted),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("TIE ⚪", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
