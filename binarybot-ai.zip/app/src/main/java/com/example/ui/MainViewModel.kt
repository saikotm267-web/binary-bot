package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BinaryBotApplication
import com.example.data.api.GeminiTradingApi
import com.example.data.db.TradeEntity
import com.example.data.model.SignalResult
import com.example.data.preferences.BotSettings
import com.example.data.repository.TradeStats
import com.example.service.FloatingBotService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface ApiTestState {
    object Idle : ApiTestState
    object Testing : ApiTestState
    data class Success(val message: String) : ApiTestState
    data class Error(val message: String) : ApiTestState
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as BinaryBotApplication
    private val settingsRepo = app.settingsRepository
    private val tradeRepo = app.tradeRepository
    private val tradingApi = GeminiTradingApi()

    val settings: StateFlow<BotSettings> = settingsRepo.settings.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = BotSettings(
            apiKey = "",
            timeframe = "1 MIN",
            modelName = "gemini-3.5-flash",
            autoDismissSeconds = 6,
            hapticFeedback = true,
            soundAlert = true,
            isBotEnabled = false
        )
    )

    val stats: StateFlow<TradeStats> = tradeRepo.stats.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = TradeStats()
    )

    val trades: StateFlow<List<TradeEntity>> = tradeRepo.allTrades.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val isBotRunning: StateFlow<Boolean> = FloatingBotService.isServiceRunning

    val lastFloatingSignal: StateFlow<SignalResult?> = FloatingBotService.lastSignal

    private val _inAppAnalysisResult = MutableStateFlow<SignalResult?>(null)
    val inAppAnalysisResult: StateFlow<SignalResult?> = _inAppAnalysisResult.asStateFlow()

    private val _isInAppAnalyzing = MutableStateFlow(false)
    val isInAppAnalyzing: StateFlow<Boolean> = _isInAppAnalyzing.asStateFlow()

    private val _inAppError = MutableStateFlow<String?>(null)
    val inAppError: StateFlow<String?> = _inAppError.asStateFlow()

    private val _apiTestState = MutableStateFlow<ApiTestState>(ApiTestState.Idle)
    val apiTestState: StateFlow<ApiTestState> = _apiTestState.asStateFlow()

    fun saveApiKey(key: String) {
        viewModelScope.launch {
            settingsRepo.saveApiKey(key)
        }
    }

    fun saveTimeframe(tf: String) {
        viewModelScope.launch {
            settingsRepo.saveTimeframe(tf)
        }
    }

    fun saveModelName(model: String) {
        viewModelScope.launch {
            settingsRepo.saveModelName(model)
        }
    }

    fun saveAutoDismissSeconds(sec: Int) {
        viewModelScope.launch {
            settingsRepo.saveAutoDismissSeconds(sec)
        }
    }

    fun saveHaptic(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepo.saveHapticFeedback(enabled)
        }
    }

    fun saveSound(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepo.saveSoundAlert(enabled)
        }
    }

    fun updateTradeResult(id: Long, result: String) {
        viewModelScope.launch {
            tradeRepo.updateResult(id, result)
        }
    }

    fun deleteTrade(id: Long) {
        viewModelScope.launch {
            tradeRepo.deleteTrade(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            tradeRepo.clearHistory()
        }
    }

    fun testApiConnection() {
        viewModelScope.launch {
            _apiTestState.value = ApiTestState.Testing
            val currentSettings = settingsRepo.settings.first()
            if (currentSettings.apiKey.isBlank()) {
                _apiTestState.value = ApiTestState.Error("API Key cannot be empty!")
                return@launch
            }

            // Create a small test candlestick chart bitmap
            val testChart = createSampleChartBitmap(patternType = "bullish_hammer")
            val result = tradingApi.analyzeChart(
                apiKey = currentSettings.apiKey,
                bitmap = testChart,
                timeframe = currentSettings.timeframe,
                modelName = currentSettings.modelName
            )

            result.onSuccess { signalResult ->
                _apiTestState.value = ApiTestState.Success(
                    "Connected! Model: ${currentSettings.modelName} | Signal: ${signalResult.signal} (${signalResult.confidence})"
                )
            }.onFailure { error ->
                _apiTestState.value = ApiTestState.Error(error.message ?: "Connection failed")
            }
        }
    }

    fun clearApiTestState() {
        _apiTestState.value = ApiTestState.Idle
    }

    fun analyzeChartBitmap(bitmap: Bitmap, chartName: String = "In-App Chart Test") {
        viewModelScope.launch {
            _isInAppAnalyzing.value = true
            _inAppError.value = null
            _inAppAnalysisResult.value = null

            val currentSettings = settingsRepo.settings.first()
            if (currentSettings.apiKey.isBlank()) {
                _isInAppAnalyzing.value = false
                _inAppError.value = "Please enter and save your Gemini API Key in Settings first!"
                return@launch
            }

            val result = tradingApi.analyzeChart(
                apiKey = currentSettings.apiKey,
                bitmap = bitmap,
                timeframe = currentSettings.timeframe,
                modelName = currentSettings.modelName
            )

            _isInAppAnalyzing.value = false

            result.onSuccess { signalResult ->
                _inAppAnalysisResult.value = signalResult

                val thumb = tradingApi.bitmapToBase64(bitmap, maxDimension = 300, quality = 60)
                tradeRepo.insertTrade(
                    TradeEntity(
                        signal = signalResult.signal,
                        confidence = signalResult.confidence,
                        timeframe = signalResult.timeframe,
                        timestamp = System.currentTimeMillis(),
                        result = "PENDING",
                        thumbnailBase64 = thumb,
                        brokerName = chartName
                    )
                )
            }.onFailure { error ->
                _inAppError.value = error.message ?: "Unknown analysis error"
            }
        }
    }

    fun clearInAppResult() {
        _inAppAnalysisResult.value = null
        _inAppError.value = null
    }

    /**
     * Generates clean realistic financial candlestick chart bitmaps for immediate in-app sandbox testing
     */
    fun createSampleChartBitmap(patternType: String = "bullish_hammer"): Bitmap {
        val width = 640
        val height = 400
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Dark background
        canvas.drawColor(AndroidColor.parseColor("#0B0F19"))

        // Grid lines
        val gridPaint = Paint().apply {
            color = AndroidColor.parseColor("#1E293B")
            strokeWidth = 1f
            style = Paint.Style.STROKE
        }
        for (y in 50..350 step 50) {
            canvas.drawLine(0f, y.toFloat(), width.toFloat(), y.toFloat(), gridPaint)
        }
        for (x in 60..580 step 60) {
            canvas.drawLine(x.toFloat(), 0f, x.toFloat(), height.toFloat(), gridPaint)
        }

        // Support line
        val srPaint = Paint().apply {
            color = AndroidColor.parseColor("#00E5FF")
            strokeWidth = 2f
            style = Paint.Style.STROKE
            isAntiAlias = true
        }
        canvas.drawLine(30f, 320f, (width - 30).toFloat(), 320f, srPaint)

        val textPaint = Paint().apply {
            color = AndroidColor.parseColor("#94A3B8")
            textSize = 14f
            isAntiAlias = true
        }
        canvas.drawText("STRONG SUPPORT ZONE @ 1.08500", 40f, 312f, textPaint)

        // Draw candlesticks (Open, High, Low, Close)
        data class Candle(val o: Float, val h: Float, val l: Float, val c: Float)
        val candles = when (patternType) {
            "bullish_hammer" -> listOf(
                Candle(150f, 140f, 180f, 175f),
                Candle(175f, 160f, 210f, 205f),
                Candle(205f, 190f, 250f, 245f),
                Candle(245f, 230f, 290f, 285f),
                Candle(285f, 270f, 325f, 318f), // hits support
                Candle(318f, 310f, 325f, 280f), // bullish hammer / rejection
                Candle(280f, 240f, 285f, 245f)  // strong green follow up
            )
            "bearish_rejection" -> listOf(
                Candle(300f, 290f, 320f, 270f),
                Candle(270f, 250f, 280f, 230f),
                Candle(230f, 190f, 240f, 170f),
                Candle(170f, 130f, 175f, 140f), // hits resistance
                Candle(140f, 120f, 170f, 165f), // shooting star rejection wick
                Candle(165f, 160f, 210f, 205f)  // strong red dump
            )
            else -> listOf( // choppy
                Candle(200f, 180f, 220f, 205f),
                Candle(205f, 190f, 215f, 195f),
                Candle(195f, 175f, 225f, 202f),
                Candle(202f, 185f, 210f, 198f),
                Candle(198f, 180f, 215f, 203f)
            )
        }

        val greenPaint = Paint().apply {
            color = AndroidColor.parseColor("#00E676")
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val redPaint = Paint().apply {
            color = AndroidColor.parseColor("#FF1744")
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        val candleWidth = 28f
        val startX = 80f
        val gap = 65f

        candles.forEachIndexed { index, candle ->
            val cx = startX + (index * gap)
            val isGreen = candle.c < candle.o // In canvas Y, smaller Y is higher price
            val paint = if (isGreen) greenPaint else redPaint

            // Wick
            canvas.drawLine(cx, candle.h, cx, candle.l, paint.apply { strokeWidth = 2.5f })

            // Body
            val top = Math.min(candle.o, candle.c)
            val bottom = Math.max(candle.o, candle.c)
            val bodyH = Math.max(bottom - top, 4f)
            canvas.drawRect(cx - (candleWidth / 2), top, cx + (candleWidth / 2), top + bodyH, paint)
        }

        return bitmap
    }
}
