package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trades")
data class TradeEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val signal: String, // BUY, SELL, WAIT
    val confidence: String, // e.g. 96%
    val timeframe: String, // e.g. 1 MIN
    val timestamp: Long = System.currentTimeMillis(),
    val result: String = "PENDING", // PENDING, WIN, LOSS, TIE
    val thumbnailBase64: String? = null,
    val brokerName: String = "Broker Chart"
)
