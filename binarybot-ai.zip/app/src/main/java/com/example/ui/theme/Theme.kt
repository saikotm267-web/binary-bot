package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val ProfessionalPolishColorScheme = darkColorScheme(
    primary = ProAccentBlue,
    onPrimary = ProAccentBlueDark,
    primaryContainer = ProAccentBlueMuted,
    onPrimaryContainer = ProAccentBlue,
    secondary = BuyGreen,
    onSecondary = Color(0xFF00391F),
    secondaryContainer = Color(0xFF00522E),
    onSecondaryContainer = BuyGreenLight,
    tertiary = WaitAmber,
    background = ProBg,
    onBackground = TextPrimary,
    surface = ProCard,
    onSurface = TextPrimary,
    surfaceVariant = ProItem,
    onSurfaceVariant = TextSecondary,
    outline = ProBorder,
    outlineVariant = ProBorderLight,
    error = SellRed
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = ProfessionalPolishColorScheme,
        typography = Typography,
        content = content
    )
}
