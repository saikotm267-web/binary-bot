package com.example.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.data.api.GeminiTradingApi
import com.example.data.db.TradeDatabase
import com.example.data.db.TradeEntity
import com.example.data.model.SignalResult
import com.example.data.preferences.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class FloatingBotService : Service() {

    companion object {
        const val CHANNEL_ID = "binary_bot_floating_service"
        const val NOTIFICATION_ID = 9921
        const val ACTION_START = "com.example.service.START_BOT"
        const val ACTION_STOP = "com.example.service.STOP_BOT"
        const val ACTION_ANALYZE = "com.example.service.ANALYZE_NOW"

        private val _isServiceRunning = MutableStateFlow(false)
        val isServiceRunning: StateFlow<Boolean> = _isServiceRunning

        private val _lastSignal = MutableStateFlow<SignalResult?>(null)
        val lastSignal: StateFlow<SignalResult?> = _lastSignal

        private val _isAnalyzing = MutableStateFlow(false)
        val isAnalyzing: StateFlow<Boolean> = _isAnalyzing
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var windowManager: WindowManager
    private lateinit var settingsRepository: SettingsRepository
    private lateinit var tradeDatabase: TradeDatabase
    private val tradingApi = GeminiTradingApi()
    private val mainHandler = Handler(Looper.getMainLooper())

    private var floatingBubbleView: View? = null
    private var hudCardView: View? = null
    private var bubbleLayoutParams: WindowManager.LayoutParams? = null
    private var autoDismissRunnable: Runnable? = null

    private var lastTradeId: Long = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        settingsRepository = SettingsRepository(this)
        tradeDatabase = TradeDatabase.getDatabase(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopFloatingBot()
                return START_NOT_STICKY
            }
            ACTION_ANALYZE -> {
                performInstantScreenAnalysis()
                return START_STICKY
            }
            else -> {
                startForegroundServiceWithNotification()
                initFloatingOverlay()
                _isServiceRunning.value = true
            }
        }
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "BinaryBot AI Active Scanner",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Running floating overlay and instant chart analyzer"
                setShowBadge(false)
            }
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager?.createNotificationChannel(channel)
        }
    }

    private fun startForegroundServiceWithNotification() {
        val appIntent = Intent(this, MainActivity::class.java)
        val pendingAppIntent = PendingIntent.getActivity(
            this, 0, appIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, FloatingBotService::class.java).apply {
            action = ACTION_STOP
        }
        val pendingStopIntent = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🤖 BinaryBot AI Active")
            .setContentText("Tap floating 🤖 over any broker to get instant BUY/SELL signal")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pendingAppIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop Bot", pendingStopIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initFloatingOverlay() {
        if (floatingBubbleView != null) return

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        bubbleLayoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 350
        }

        floatingBubbleView = createBubbleLayout()

        try {
            windowManager.addView(floatingBubbleView, bubbleLayoutParams)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Overlay permission required", Toast.LENGTH_SHORT).show()
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createBubbleLayout(): View {
        val container = FrameLayout(this).apply {
            val dp4 = dpToPx(4)
            setPadding(dp4, dp4, dp4, dp4)
        }

        // Professional Polish floating bubble
        val bubbleBackground = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#D0E4FF"))
            setStroke(dpToPx(3), Color.parseColor("#0F1115"))
        }

        val innerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = bubbleBackground
            val pad = dpToPx(8)
            setPadding(pad, pad, pad, pad)
            layoutParams = FrameLayout.LayoutParams(dpToPx(56), dpToPx(56))
        }

        val robotIcon = TextView(this).apply {
            text = "🤖"
            textSize = 22f
            gravity = Gravity.CENTER
        }

        val statusText = TextView(this).apply {
            text = "AI SCAN"
            textSize = 8f
            setTextColor(Color.parseColor("#00E5FF"))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }

        innerLayout.addView(robotIcon)
        innerLayout.addView(statusText)
        container.addView(innerLayout)

        // Drag & Tap touch listener
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false

        container.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = bubbleLayoutParams?.x ?: 0
                    initialY = bubbleLayoutParams?.y ?: 0
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val deltaX = (event.rawX - initialTouchX).toInt()
                    val deltaY = (event.rawY - initialTouchY).toInt()
                    if (Math.abs(deltaX) > 10 || Math.abs(deltaY) > 10) {
                        isDragging = true
                    }
                    if (isDragging && bubbleLayoutParams != null) {
                        bubbleLayoutParams?.x = initialX + deltaX
                        bubbleLayoutParams?.y = initialY + deltaY
                        try {
                            windowManager.updateViewLayout(floatingBubbleView, bubbleLayoutParams)
                        } catch (e: Exception) {
                            // ignore
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        // Click event: Trigger Instant Screen Analysis!
                        performInstantScreenAnalysis()
                    }
                    true
                }
                else -> false
            }
        }

        return container
    }

    /**
     * Instant Screen Capture via MediaProjection & Gemini API Analysis
     */
    fun performInstantScreenAnalysis() {
        if (_isAnalyzing.value) return
        _isAnalyzing.value = true

        serviceScope.launch {
            try {
                // Pulse feedback
                vibrateDevice(50)

                // 1. Capture screen bitmap
                val bitmap = captureScreenBitmap()
                if (bitmap == null) {
                    _isAnalyzing.value = false
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@FloatingBotService, "Could not capture screen. Check capture permission.", Toast.LENGTH_LONG).show()
                    }
                    return@launch
                }

                // 2. Fetch settings
                val settings = settingsRepository.settings.first()
                if (settings.apiKey.isBlank()) {
                    _isAnalyzing.value = false
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@FloatingBotService, "Gemini API key is missing! Open app settings.", Toast.LENGTH_LONG).show()
                    }
                    return@launch
                }

                // 3. Send to Gemini Vision API
                val result = tradingApi.analyzeChart(
                    apiKey = settings.apiKey,
                    bitmap = bitmap,
                    timeframe = settings.timeframe,
                    modelName = settings.modelName
                )

                _isAnalyzing.value = false

                result.onSuccess { signalResult ->
                    _lastSignal.value = signalResult

                    // Save trade to DB
                    val thumb = tradingApi.bitmapToBase64(bitmap, maxDimension = 320, quality = 60)
                    val tradeEntity = TradeEntity(
                        signal = signalResult.signal,
                        confidence = signalResult.confidence,
                        timeframe = signalResult.timeframe,
                        timestamp = System.currentTimeMillis(),
                        result = "PENDING",
                        thumbnailBase64 = thumb,
                        brokerName = "Live Broker"
                    )
                    lastTradeId = tradeDatabase.tradeDao().insertTrade(tradeEntity)

                    // Vibrate on signal
                    if (settings.hapticFeedback) {
                        if (signalResult.signal == "BUY" || signalResult.signal == "SELL") {
                            vibratePattern(longArrayOf(0, 100, 50, 100))
                        } else {
                            vibrateDevice(80)
                        }
                    }

                    // Display Instant HUD Pop-Up Card
                    showSignalHudCard(signalResult, settings.autoDismissSeconds)
                }.onFailure { error ->
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@FloatingBotService, "Analysis Error: ${error.message}", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                _isAnalyzing.value = false
                Log.e("FloatingBotService", "Error during analysis", e)
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@FloatingBotService, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    /**
     * Captures the screen frame via MediaProjection ImageReader
     */
    private suspend fun captureScreenBitmap(): Bitmap? = withContext(Dispatchers.IO) {
        val projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mediaProjection = MediaProjectionHolder.initProjection(projectionManager) ?: return@withContext null

        val metrics = DisplayMetrics()
        windowManager.defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        val imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        var virtualDisplay: VirtualDisplay? = null

        try {
            virtualDisplay = mediaProjection.createVirtualDisplay(
                "BinaryBotCapture",
                width,
                height,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.surface,
                null,
                null
            )

            // Wait brief moment for frame buffer to render
            kotlinx.coroutines.delay(120)

            val image = imageReader.acquireLatestImage() ?: return@withContext null
            val planes = image.planes
            val buffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val rowPadding = rowStride - pixelStride * width

            val bitmap = Bitmap.createBitmap(
                width + rowPadding / pixelStride,
                height,
                Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(buffer)
            image.close()

            // Crop excess padding if rowStride was padded
            val croppedBitmap = if (rowPadding > 0) {
                Bitmap.createBitmap(bitmap, 0, 0, width, height)
            } else {
                bitmap
            }

            croppedBitmap
        } catch (e: Exception) {
            Log.e("FloatingBotService", "Failed to capture screen", e)
            null
        } finally {
            virtualDisplay?.release()
            imageReader.close()
        }
    }

    /**
     * Shows compact, sleek HUD pop-up card overlay over the broker screen
     */
    private fun showSignalHudCard(signal: SignalResult, autoDismissSec: Int) {
        dismissHudCard()

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val hudParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 120
        }

        val cardView = createHudCardLayout(signal)
        hudCardView = cardView

        try {
            windowManager.addView(cardView, hudParams)

            // Auto dismiss timer
            if (autoDismissSec > 0) {
                autoDismissRunnable = Runnable {
                    dismissHudCard()
                }
                mainHandler.postDelayed(autoDismissRunnable!!, (autoDismissSec * 1000).toLong())
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun dismissHudCard() {
        autoDismissRunnable?.let { mainHandler.removeCallbacks(it) }
        autoDismissRunnable = null
        hudCardView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                // ignore
            }
            hudCardView = null
        }
    }

    private fun createHudCardLayout(signal: SignalResult): View {
        val root = FrameLayout(this).apply {
            setPadding(dpToPx(16), dpToPx(8), dpToPx(16), dpToPx(8))
        }

        val isBuy = signal.normalizedSignal == com.example.data.model.SignalType.BUY
        val isSell = signal.normalizedSignal == com.example.data.model.SignalType.SELL

        val accentColor = when {
            isBuy -> Color.parseColor("#10B981") // Emerald Green
            isSell -> Color.parseColor("#F43F5E") // Rose Red
            else -> Color.parseColor("#F59E0B") // Amber Gold
        }

        val cardBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpToPx(24).toFloat()
            setColor(Color.parseColor("#F00A0C10")) // Dark luxury matte backdrop
            setStroke(dpToPx(1), accentColor)
        }

        val mainCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = cardBg
            val p = dpToPx(18)
            setPadding(p, p, p, p)
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            )
        }

        // Top Header Row
        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val liveTag = TextView(this).apply {
            text = "● LIVE ANALYSIS"
            setTextColor(Color.parseColor("#10B981"))
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val tfBadge = TextView(this).apply {
            text = signal.timeframe
            setTextColor(Color.parseColor("#E2E2E6"))
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            val bg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpToPx(6).toFloat()
                setColor(Color.parseColor("#1F242D"))
            }
            background = bg
            setPadding(dpToPx(8), dpToPx(3), dpToPx(8), dpToPx(3))
        }

        val closeBtn = TextView(this).apply {
            text = " ✕ "
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dpToPx(8), 0, 0, 0)
            setOnClickListener {
                dismissHudCard()
            }
        }

        headerRow.addView(liveTag)
        headerRow.addView(tfBadge)
        headerRow.addView(closeBtn)
        mainCard.addView(headerRow)

        // Main Signal Row
        val signalRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dpToPx(10), 0, dpToPx(8))
        }

        val signalLabel = TextView(this).apply {
            text = when {
                isBuy -> "CALL (BUY)"
                isSell -> "PUT (SELL)"
                else -> "WAIT"
            }
            setTextColor(accentColor)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val confText = TextView(this).apply {
            text = signal.confidence
            setTextColor(Color.parseColor("#D0E4FF"))
            textSize = 13f
            typeface = Typeface.MONOSPACE
            val confBg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpToPx(6).toFloat()
                setColor(Color.parseColor("#1F242D"))
            }
            background = confBg
            setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4))
        }

        signalRow.addView(signalLabel)
        signalRow.addView(confText)
        mainCard.addView(signalRow)

        // JSON Spec Banner
        val jsonBanner = TextView(this).apply {
            text = """{ "signal": "${signal.signal}", "confidence": "${signal.confidence}", "timeframe": "${signal.timeframe}" }"""
            setTextColor(Color.parseColor("#64748B"))
            textSize = 9f
            typeface = Typeface.MONOSPACE
            setPadding(0, 0, 0, dpToPx(10))
        }
        mainCard.addView(jsonBanner)

        // Fast Outcome Buttons
        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        fun createOutcomeButton(label: String, color: Int, resultTag: String): Button {
            return Button(this).apply {
                text = label
                textSize = 11f
                setTextColor(Color.WHITE)
                val bg = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpToPx(10).toFloat()
                    setColor(color)
                }
                background = bg
                layoutParams = LinearLayout.LayoutParams(0, dpToPx(36), 1f).apply {
                    setMargins(dpToPx(3), 0, dpToPx(3), 0)
                }
                setOnClickListener {
                    if (lastTradeId > 0) {
                        serviceScope.launch {
                            tradeDatabase.tradeDao().updateTradeResult(lastTradeId, resultTag)
                        }
                    }
                    vibrateDevice(50)
                    Toast.makeText(this@FloatingBotService, "Trade logged as $resultTag!", Toast.LENGTH_SHORT).show()
                    dismissHudCard()
                }
            }
        }

        val winBtn = createOutcomeButton("WIN 🎯", Color.parseColor("#10B981"), "WIN")
        val lossBtn = createOutcomeButton("LOSS ❌", Color.parseColor("#F43F5E"), "LOSS")
        val tieBtn = createOutcomeButton("TIE ⚪", Color.parseColor("#3E4759"), "TIE")

        actionRow.addView(winBtn)
        actionRow.addView(lossBtn)
        actionRow.addView(tieBtn)
        mainCard.addView(actionRow)

        root.addView(mainCard)
        return root
    }

    private fun vibrateDevice(millis: Long) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = getSystemService(VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(millis, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = getSystemService(VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(millis, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(millis)
                }
            }
        } catch (e: Exception) {
            // ignore
        }
    }

    private fun vibratePattern(pattern: LongArray) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = getSystemService(VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createWaveform(pattern, -1)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = getSystemService(VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createWaveform(pattern, -1))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(pattern, -1)
                }
            }
        } catch (e: Exception) {
            // ignore
        }
    }

    private fun dpToPx(dp: Int): Int {
        val density = resources.displayMetrics.density
        return (dp * density).toInt()
    }

    private fun stopFloatingBot() {
        dismissHudCard()
        floatingBubbleView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                // ignore
            }
            floatingBubbleView = null
        }
        _isServiceRunning.value = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopFloatingBot()
        serviceScope.cancel()
        super.onDestroy()
    }
}
