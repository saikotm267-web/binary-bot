package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class SignalResult(
    @Json(name = "signal")
    val signal: String = "WAIT", // BUY, SELL, WAIT

    @Json(name = "confidence")
    val confidence: String = "0%", // e.g. "96%"

    @Json(name = "timeframe")
    val timeframe: String = "1 MIN" // e.g. "1 MIN"
) {
    val normalizedSignal: SignalType
        get() = when (signal.uppercase().trim()) {
            "BUY", "CALL", "UP", "GREEN" -> SignalType.BUY
            "SELL", "PUT", "DOWN", "RED" -> SignalType.SELL
            else -> SignalType.WAIT
        }

    val confidenceValue: Int
        get() {
            val digits = confidence.filter { it.isDigit() }
            return digits.toIntOrNull() ?: 0
        }
}

enum class SignalType {
    BUY,
    SELL,
    WAIT
}
