package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.BuildConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "binary_bot_settings")

data class BotSettings(
    val apiKey: String,
    val timeframe: String,
    val modelName: String,
    val autoDismissSeconds: Int,
    val hapticFeedback: Boolean,
    val soundAlert: Boolean,
    val isBotEnabled: Boolean
)

class SettingsRepository(private val context: Context) {

    companion object {
        private val KEY_API_KEY = stringPreferencesKey("gemini_api_key")
        private val KEY_TIMEFRAME = stringPreferencesKey("selected_timeframe")
        private val KEY_MODEL_NAME = stringPreferencesKey("gemini_model_name")
        private val KEY_AUTO_DISMISS = intPreferencesKey("auto_dismiss_seconds")
        private val KEY_HAPTIC = booleanPreferencesKey("haptic_feedback")
        private val KEY_SOUND = booleanPreferencesKey("sound_alert")
        private val KEY_BOT_ENABLED = booleanPreferencesKey("bot_enabled")

        const val DEFAULT_MODEL = "gemini-3.5-flash"
        const val DEFAULT_TIMEFRAME = "1 MIN"
    }

    val settings: Flow<BotSettings> = context.dataStore.data.map { preferences ->
        val savedKey = preferences[KEY_API_KEY] ?: ""
        // Fallback to BuildConfig.GEMINI_API_KEY if user hasn't explicitly set one or if empty
        val effectiveApiKey = if (savedKey.isNotBlank()) savedKey else (try { BuildConfig.GEMINI_API_KEY } catch (e: Exception) { "" })

        BotSettings(
            apiKey = effectiveApiKey,
            timeframe = preferences[KEY_TIMEFRAME] ?: DEFAULT_TIMEFRAME,
            modelName = preferences[KEY_MODEL_NAME] ?: DEFAULT_MODEL,
            autoDismissSeconds = preferences[KEY_AUTO_DISMISS] ?: 6,
            hapticFeedback = preferences[KEY_HAPTIC] ?: true,
            soundAlert = preferences[KEY_SOUND] ?: true,
            isBotEnabled = preferences[KEY_BOT_ENABLED] ?: false
        )
    }

    suspend fun saveApiKey(apiKey: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_API_KEY] = apiKey.trim()
        }
    }

    suspend fun saveTimeframe(timeframe: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_TIMEFRAME] = timeframe
        }
    }

    suspend fun saveModelName(modelName: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_MODEL_NAME] = modelName
        }
    }

    suspend fun saveAutoDismissSeconds(seconds: Int) {
        context.dataStore.edit { preferences ->
            preferences[KEY_AUTO_DISMISS] = seconds
        }
    }

    suspend fun saveHapticFeedback(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[KEY_HAPTIC] = enabled
        }
    }

    suspend fun saveSoundAlert(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[KEY_SOUND] = enabled
        }
    }

    suspend fun saveBotEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[KEY_BOT_ENABLED] = enabled
        }
    }
}
