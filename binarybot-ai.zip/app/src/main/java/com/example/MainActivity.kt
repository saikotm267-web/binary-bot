package com.example

import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.service.MediaProjectionHolder
import com.example.ui.MainViewModel
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PermissionsScreen
import com.example.ui.theme.BuyGreen
import com.example.ui.theme.BuyGreenLight
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.ProAccentBlue
import com.example.ui.theme.ProAccentBlueDark
import com.example.ui.theme.ProAccentBlueMuted
import com.example.ui.theme.ProBg
import com.example.ui.theme.ProBorder
import com.example.ui.theme.ProBorderLight
import com.example.ui.theme.ProCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

enum class AppTab(val title: String, val icon: ImageVector, val tag: String) {
    HOME("HOME", Icons.Default.Home, "tab_home"),
    TRADES("TRADES", Icons.Default.Analytics, "tab_trades"),
    SETUP("SYSTEM", Icons.Default.Security, "tab_setup")
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val context = LocalContext.current
                val isBotRunning by viewModel.isBotRunning.collectAsStateWithLifecycle()

                val hasOverlay = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    Settings.canDrawOverlays(context)
                } else true
                val hasCapture = MediaProjectionHolder.hasPermission()

                var selectedTabIndex by remember {
                    mutableIntStateOf(if (hasOverlay && hasCapture) 0 else 2)
                }

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(ProBg),
                    topBar = {
                        Column(modifier = Modifier.background(ProBg)) {
                            TopAppBar(
                                title = {
                                    Column {
                                        Text(
                                            text = "BinaryEdge Pro",
                                            color = ProAccentBlue,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 20.sp,
                                            letterSpacing = (-0.5).sp
                                        )
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.padding(top = 2.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(7.dp)
                                                    .clip(CircleShape)
                                                    .background(if (isBotRunning) BuyGreen else TextMuted)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = if (isBotRunning) "ENGINE ONLINE" else "STANDBY READY",
                                                color = if (isBotRunning) BuyGreenLight else TextSecondary,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                letterSpacing = 1.sp
                                            )
                                        }
                                    }
                                },
                                actions = {
                                    // Professional Polish Executive Badge
                                    Box(
                                        modifier = Modifier
                                            .padding(end = 16.dp)
                                            .size(38.dp)
                                            .clip(CircleShape)
                                            .background(ProAccentBlueMuted)
                                            .border(1.dp, ProBorderLight, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "AI",
                                            color = ProAccentBlue,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                    }
                                },
                                colors = TopAppBarDefaults.topAppBarColors(
                                    containerColor = ProBg,
                                    titleContentColor = ProAccentBlue
                                )
                            )
                            HorizontalDivider(color = ProBorder.copy(alpha = 0.5f), thickness = 1.dp)
                        }
                    },
                    bottomBar = {
                        Column {
                            HorizontalDivider(color = ProBorder, thickness = 1.dp)
                            NavigationBar(
                                containerColor = Color(0xFF1A1C22),
                                tonalElevation = 0.dp,
                                modifier = Modifier.height(72.dp)
                            ) {
                                AppTab.values().forEachIndexed { index, tab ->
                                    val isSelected = selectedTabIndex == index
                                    NavigationBarItem(
                                        selected = isSelected,
                                        onClick = { selectedTabIndex = index },
                                        icon = {
                                            Icon(
                                                imageVector = tab.icon,
                                                contentDescription = tab.title,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        },
                                        label = {
                                            Text(
                                                text = tab.title,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                letterSpacing = 0.5.sp
                                            )
                                        },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = ProAccentBlueDark,
                                            selectedTextColor = ProAccentBlue,
                                            indicatorColor = ProAccentBlue,
                                            unselectedIconColor = TextMuted,
                                            unselectedTextColor = TextMuted
                                        ),
                                        modifier = Modifier.testTag(tab.tag)
                                    )
                                }
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(ProBg)
                            .padding(innerPadding)
                    ) {
                        AnimatedContent(
                            targetState = selectedTabIndex,
                            transitionSpec = { fadeIn() togetherWith fadeOut() },
                            label = "tabContent"
                        ) { targetTab ->
                            when (targetTab) {
                                0 -> HomeScreen(
                                    viewModel = viewModel,
                                    onOpenPermissions = { selectedTabIndex = 2 }
                                )
                                1 -> HistoryScreen(
                                    viewModel = viewModel
                                )
                                2 -> PermissionsScreen(
                                    onContinueToHome = { selectedTabIndex = 0 }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
