package com.example.data.api

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.example.data.model.SignalResult
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    @Json(name = "contents") val contents: List<GeminiContent>,
    @Json(name = "generationConfig") val generationConfig: GeminiGenerationConfig? = null
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
    @Json(name = "parts") val parts: List<GeminiPart>
)

@JsonClass(generateAdapter = true)
data class GeminiPart(
    @Json(name = "text") val text: String? = null,
    @Json(name = "inlineData") val inlineData: GeminiInlineData? = null
)

@JsonClass(generateAdapter = true)
data class GeminiInlineData(
    @Json(name = "mimeType") val mimeType: String,
    @Json(name = "data") val data: String
)

@JsonClass(generateAdapter = true)
data class GeminiGenerationConfig(
    @Json(name = "temperature") val temperature: Float = 0.1f,
    @Json(name = "responseMimeType") val responseMimeType: String? = "application/json"
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    @Json(name = "candidates") val candidates: List<GeminiCandidate>? = null,
    @Json(name = "error") val error: GeminiError? = null
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
    @Json(name = "content") val content: GeminiContent? = null
)

@JsonClass(generateAdapter = true)
data class GeminiError(
    @Json(name = "message") val message: String? = null,
    @Json(name = "code") val code: Int? = null
)

class GeminiTradingApi {

    private val moshi: Moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val signalAdapter = moshi.adapter(SignalResult::class.java)
    private val requestAdapter = moshi.adapter(GeminiRequest::class.java)
    private val responseAdapter = moshi.adapter(GeminiResponse::class.java)

    /**
     * Compress bitmap to JPEG Base64
     */
    fun bitmapToBase64(bitmap: Bitmap, maxDimension: Int = 1024, quality: Int = 85): String {
        val scaled = if (bitmap.width > maxDimension || bitmap.height > maxDimension) {
            val ratio = bitmap.width.toFloat() / bitmap.height.toFloat()
            val targetW: Int
            val targetH: Int
            if (ratio > 1) {
                targetW = maxDimension
                targetH = (maxDimension / ratio).toInt()
            } else {
                targetH = maxDimension
                targetW = (maxDimension * ratio).toInt()
            }
            Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
        } else {
            bitmap
        }

        val outputStream = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
        val byteArray = outputStream.toByteArray()
        return Base64.encodeToString(byteArray, Base64.NO_WRAP)
    }

    /**
     * Analyze chart bitmap and return SignalResult
     */
    suspend fun analyzeChart(
        apiKey: String,
        bitmap: Bitmap,
        timeframe: String = "1 MIN",
        modelName: String = "gemini-3.5-flash"
    ): Result<SignalResult> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                IllegalArgumentException("Gemini API Key is missing. Please set your API key in Settings.")
            )
        }

        val base64Image = bitmapToBase64(bitmap)

        val promptText = """
You are an Elite Price Action & Binary Options Specialist. Your job is to analyze live chart screenshots provided by the user/system and provide INSTANT, ULTRA-ACCURATE trading decisions with a >95% accuracy target.

CORE TRADING RULES:
1. S/R & Price Action Analysis:
   - Identify key Support & Resistance zones, psychological levels, and trendlines.
   - Analyze candlestick psychology, body exhaustion, and shadow/wick rejections.
2. Signal Filter:
   - If the market is choppy, sideways, or ambiguous, strictly output "WAIT".
   - Prioritize signal accuracy over volume.

TARGET TIMEFRAME: $timeframe

STRICT JSON OUTPUT FORMAT:
Return ONLY valid JSON. Do NOT include any explanations, reasons, or introductory text.

{
  "signal": "BUY" | "SELL" | "WAIT",
  "confidence": "96%",
  "timeframe": "$timeframe"
}
""".trimIndent()

        val geminiRequest = GeminiRequest(
            contents = listOf(
                GeminiContent(
                    parts = listOf(
                        GeminiPart(text = promptText),
                        GeminiPart(
                            inlineData = GeminiInlineData(
                                mimeType = "image/jpeg",
                                data = base64Image
                            )
                        )
                    )
                )
            ),
            generationConfig = GeminiGenerationConfig(
                temperature = 0.1f,
                responseMimeType = "application/json"
            )
        )

        try {
            val jsonPayload = requestAdapter.toJson(geminiRequest)
            val effectiveModel = if (modelName.isNotBlank()) modelName else "gemini-3.5-flash"
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$effectiveModel:generateContent?key=$apiKey"

            val body = jsonPayload.toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            val response = okHttpClient.newCall(request).execute()
            val responseString = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                val errorMsg = try {
                    val parsedErr = responseAdapter.fromJson(responseString)
                    parsedErr?.error?.message ?: "API returned HTTP ${response.code}"
                } catch (e: Exception) {
                    "API error HTTP ${response.code}: $responseString"
                }
                return@withContext Result.failure(Exception(errorMsg))
            }

            val parsedResponse = responseAdapter.fromJson(responseString)
            val candidateText = parsedResponse?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: return@withContext Result.failure(Exception("Empty candidate response from Gemini"))

            val cleanJson = cleanJsonString(candidateText)
            val signalResult = try {
                signalAdapter.fromJson(cleanJson)
            } catch (e: Exception) {
                // Fallback manual regex parser if strictly needed
                parseSignalFallback(candidateText, timeframe)
            }

            if (signalResult != null) {
                Result.success(signalResult)
            } else {
                Result.failure(Exception("Could not parse signal JSON: $candidateText"))
            }
        } catch (e: Exception) {
            Log.e("GeminiTradingApi", "Error analyzing chart", e)
            Result.failure(e)
        }
    }

    private fun cleanJsonString(raw: String): String {
        var text = raw.trim()
        if (text.startsWith("```json")) {
            text = text.removePrefix("```json")
        }
        if (text.startsWith("```")) {
            text = text.removePrefix("```")
        }
        if (text.endsWith("```")) {
            text = text.removeSuffix("```")
        }
        return text.trim()
    }

    private fun parseSignalFallback(raw: String, defaultTimeframe: String): SignalResult {
        val upper = raw.uppercase()
        val signal = when {
            upper.contains("\"BUY\"") || upper.contains("BUY") -> "BUY"
            upper.contains("\"SELL\"") || upper.contains("SELL") -> "SELL"
            else -> "WAIT"
        }

        val confRegex = Regex("""(\d{1,3})\s*%""")
        val confMatch = confRegex.find(raw)
        val conf = confMatch?.value ?: if (signal == "WAIT") "50%" else "95%"

        return SignalResult(
            signal = signal,
            confidence = conf,
            timeframe = defaultTimeframe
        )
    }
}
